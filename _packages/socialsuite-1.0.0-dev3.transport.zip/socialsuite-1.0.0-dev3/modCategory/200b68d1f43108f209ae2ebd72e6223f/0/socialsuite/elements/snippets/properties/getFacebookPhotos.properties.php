<?php

return array(
    'user' => '',
    'albums' => '',

    'albumTpl' => 'facebook/photos/albumtpl',
    'albumSeparator' => '<br />',
    'photoTpl' => 'facebook/photos/phototpl',
    'photoSeparator' => "\n",


    'cacheOutput' => false,
    'cacheExpiresAlbums' => 14400,
    'cacheExpiresPhotos' => 28800,
    'cacheExpiresPhotosVariation' => 3600,

    'showAvailableData' => false,
    'toPlaceholders' => false,
    'toPlaceholdersPrefix' => 'fb',

    'tpl' => ''
);
