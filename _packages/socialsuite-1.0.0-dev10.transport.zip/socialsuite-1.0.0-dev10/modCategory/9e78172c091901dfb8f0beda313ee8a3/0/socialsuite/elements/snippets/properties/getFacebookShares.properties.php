<?php

return array(
    'url' => '',
    'cache' => true,
    'cacheExpires' => 7200,
    'node' => 'shares',
);
