<?php

return array(
    'url' => '',
    'cache' => true,
    'cacheExpires' => 3600,
    'node' => 'shares',
);
