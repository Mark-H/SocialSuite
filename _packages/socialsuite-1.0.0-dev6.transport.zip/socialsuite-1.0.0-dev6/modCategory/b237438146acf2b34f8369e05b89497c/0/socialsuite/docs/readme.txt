++ SocialSuite
++ Developer: Mark Hamstra <mark@modx.com>
++ License: GPL GNU v2

SocialSuite is a collection of snippets and other useful tools to integrate social media with your website.

Documentation: 		http://rtfm.modx.com/display/ADDON/SocialSuite
Bugs & Features: 	https://github.com/Mark-H/SocialSuite/issues
