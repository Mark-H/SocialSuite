<?php

return array(
    'user' => '', // the username
    'cache' => true,
    'cacheExpires' => 3600,

    'showAvailableData' => false,
    'toPlaceholders' => false,
    'toPlaceholdersPrefix' => 'fb',

    'tpl' => ''
);
